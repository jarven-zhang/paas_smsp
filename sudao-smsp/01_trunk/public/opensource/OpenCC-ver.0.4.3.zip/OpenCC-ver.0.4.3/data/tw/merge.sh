python ../scripts/merge.py tw-it.txt tw-other.txt tw-name.txt to_tw_phrases.txt
