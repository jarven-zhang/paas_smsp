python ../scripts/merge.py cn-it.txt cn-other.txt cn-name.txt to_cn_phrases.txt
